<?php
session_start();
////$a=$_REQUEST['va'].__toString();
//$_SESSION['data']=$_REQUEST['data'];
////$_SESSION['user']=$a;
////$_SESSION['photo']=$_REQUEST['sample'];
//echo json_encode($_SESSION['data']);
////console.log($mySession);
////echo $_SESSION['photo'];
////header("location:my.php");
//
?>
<div id="t1">
</div>
<img src="" id="im" height="50px" width="50px">
<!---->
<script>
    var user=JSON.parse(sessionStorage.getItem("user"));
   // console.log(user);
    var c=user[0].name;
    alert(c);
    var d="http://localhost:7000/"+user[0].image;
    alert(d);
    document.getElementById('t1').innerHTML=c;
    document.getElementById('im').src=d;
</script>
