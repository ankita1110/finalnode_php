<html>
<head>
    <script src="https://code.jquery.com/jquery-1.12.4.min.js">
    </script>
</head>
<body>
<form method="post" action="">
    <input type="text" name="username" id="username">
    <input type="text" name="password" id="password">
    <input type="submit" name="submit" id="bu" value="submit">
</form>
</body>
<script type="text/javascript">
    $(document).ready(function() {
        $("#bu").click(function () {
           // alert();
            var username = $("#username").val();
            var password = $("#password").val();
           // var myVal = '@Session["ss"]';
           // var sessionValue = '<%=Session["user"]%>'
           // console.log(sessionValue);
           // sessionStorage.setItem("MyId",);
           // var value = sessionStorage.getItem("MyId");
           // var photo=$('photo')
            alert(username+""+password);
            $.ajax({

                type: 'POST',
                url: "http://192.168.200.29:7000/login",
                data: {username:username,password:password},
                success: function (data) {
                   // console.log("data " +data);
                  //  alert(data);
                    // $(".my").html(data);
                    if(data)
                    {

                        sessionStorage.setItem('user', JSON.stringify(data));
                       //    var a=sessionStorage.setItem("user",data);
                       //    alert(a);
                       //    var value = sessionStorage.getItem("user");
                       // console.log( value);
                       //alert(JSON.stringify(data));
                       // alert(JSON.stringify(value));
                        //alert(data);
                       // my();
                        //console.log(value);
                      window.location= "my.php";
                        //alert('success');
                    }
                }
            });
        });
    });
        </script>
</html>