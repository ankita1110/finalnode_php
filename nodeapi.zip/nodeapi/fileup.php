<html>
<head>
    <script src="https://code.jquery.com/jquery-1.12.4.min.js">
    </script>
</head>
<body>
<form method="post" action="http://localhost:3000/upload" enctype="multipart/form-data">
    <input type="file" name="sample">
    <input type="submit">
    <input type="button" id="bu" name="disply" value="disply">
</form>
<div id="t1"></div>
</body>
<script type="text/javascript">

    $("#bu").click(function () {
         alert();
        $.ajax({

            type: 'GET',
            url: "http://192.168.200.29:3000/images",
            success: function (data) {
                // $(".my").html(data);
                var p="";
                if(data)
                {
                    var path=data.path;

                    for(var d in data.rows)
                    { );
                        //p += "<img src='./../img/"+data.rows[d]["name"]+"' alt='image'>";

                        p += "<img src='http://localhost:3000/"+data.rows[d]["name"]+"' alt='image'>";
                        console.log(p);
                    }
                    $("#t1").html(p);
                }
            }
        });
    });

</script>

</html>

