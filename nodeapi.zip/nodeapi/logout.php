<script>
    sessionStorage.removeItem('user');
    //sessionStorage.clear();
    window.location="login.php";
</script>