
<?php
session_start();

$image="<img src='http://localhost:4000/";

                             $image.=$_SESSION["photo"];
                             $image.="'class='avatar img-circle'/>";

echo $image;
?>
